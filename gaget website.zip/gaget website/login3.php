<?php include('loginHandler.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="signup.css">
</head>
<body>
  <div class="header">
  	<h2>Login</h2>
  </div>
	 
  <form method="post" action="loginHandler.php">
  	<?php include('signupErrorCheck.php'); ?>
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="userName" required>
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="userPW" required>
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
  		Not yet a member? <a href="signup.php">Sign up</a><br>
		<a href="forgetPW.php">Forget password</a>
  	</p>
  </form>
  <center><h1 style="font-style:bold; color:red">Wrong Username or Password!!</h1></center>
</body>
</html>
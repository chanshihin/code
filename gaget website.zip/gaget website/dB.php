<?php	
	$db_hostname = "mysql.comp.polyu.edu.hk";
	$db_username = "17048242d";
	$db_password = "tapuxwhg";
	$db_database = "17048242d";

	//create connection
	$conn = mysqli_connect(
		$db_hostname, $db_username, $db_password, $db_database);
	if(!$conn)
		die("Unable to connect to MySQL:".mysqli_connect_error());
	else
		echo "UUG";

?>
<html>
<title>Home</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/style1.css">
<link rel="stylesheet" type="text/css" href="css/style2.css">
<link rel="stylesheet" type="text/css" href="css/style3.css">

<style>
.w3-sidebar a {font-family: "Roboto", sans-serif}
body,h1,h2,h3,h4,h5,h6,.w3-wide {font-family: "Montserrat", sans-serif;}
</style>
<body class="w3-content" style="max-width:1200px">

  <!-- Top header -->
  <header class="w3-container w3-xlarge">
    <p class="w3-right">
      <a href="signup.php" class="w3-bar-item w3-button">Sign Up</a>
      <a href="login.php" class="w3-bar-item w3-button">Login</a>
    </p>
  </header>



  <!-- Image header -->
  <div class="w3-display-container w3-container">
    <img src="image/wall2.jpg" alt="wallpaper" style="width:100%">
    <img src="image/wall1.jpg" alt="wallpaper" style="width:100%">

  </div>
</div>

</body>
</html>

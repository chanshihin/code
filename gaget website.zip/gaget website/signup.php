<?php include('signupHandler.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <link rel="stylesheet" type="text/css" href="signup.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
	
  <form method="post" action="signup.php">
  	<?php include('signupErrorCheck.php'); ?>
  	<div class="input-group">
  	  <label for="userName">Username</label>
  	  <input type="text" name="userName" value="<?=$userName?>" required>
  	</div>
  	
  	<div class="input-group">
  	  <label for="userPW">Password</label>
  	  <input type="password" name="userPW" value="<?=$userPW?>" required>
  	</div>
  	<div class="input-group">
  	  <label for="cpw">Confirm password</label>
  	  <input type="password" name="cpw" value="<?=$cpw?>" required>
  	</div>
	<div class="input-group">
		<label for="contactNo"><b>Contact Number</b></label>
		<input type="number"  min="10000000" max="99999999" placeholder="Phone Number" name="contactNo" id="contactNo" value="<?=$contactNo?>" required><br>
	</div>
	<div class="input-group">
  	  <label for="email">Email</label>
  	  <input type="email" name="email" value="<?=$email?>" required>
  	</div>
	<div class="input-group">
  	  <label for="dob">Date of Birth</label>
  	  <input type="date" name="dob" value="<?=$dob?>" required>
  	</div>
	<div class="input-group">
  	<label for="question">Captcha Question</label>
  	<select name = "question">
		<option value="food">What is your favourite food?</option>
		<option value="school">What is the name of your primary school?</option>
		<option value="country">Which country have you been to recently? </option>
	</select>
  	</div>
	<div class="input-group">
  	  <label for="answer">Your answer</label>
  	  <input type="text" name="answer" required>
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="signup">Register</button>
  	</div>
  	<p>
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
  </form>
</body>
</html>
